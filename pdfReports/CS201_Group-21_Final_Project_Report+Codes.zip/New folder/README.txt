Run all these 3 SQL scripts line by line on the MySQL workbench with the port number 3306,
username 'root' and password 'password'.

Populate the tables by given excel sheets
----------------------------------------------------

Open the Project in eclipse run the tomcat 9 server

----------------------------------------------------

admin; email => admin@admin.com
       Password=> password

----------------------------------------------------
Please Contact me Roll No.(202051169) Satyam Gupta , in case of any issue or problem in setting up the project